import Link from "next/link";
import { lessons } from "@/db/schema";
import { leaveReview, updateLesson } from "@/lib/actions";
import type { T, Lang } from "@/lib/i18n";
import type { LearningCopy } from "@/lib/learning-i18n";
import { fmtAtZone, nowMs, isValidTimeZone, DEFAULT_TIME_ZONE } from "@/lib/time";
import { money } from "@/lib/package-pricing";
import Icon from "./Icon";
import CancelLessonButton from "./CancelLessonButton";
export type LessonRowData = { l: typeof lessons.$inferSelect; otherName: string; otherAvatar: string | null; otherId: number; teacherTimeZone?: string | null; reviewedByMe?: boolean };
const statusColor: Record<string,string> = {pending:"bg-amber-50 text-amber-700",confirmed:"bg-sky-50 text-sky-700",completed:"bg-teal-50 text-teal-700",cancelled:"bg-slate-100 text-slate-400"};
export function DashboardLessonRow({ row: x, isTutor, t, c, lang, viewerTimeZone }: { row: LessonRowData; isTutor: boolean; t: T; c: LearningCopy; lang: Lang; viewerTimeZone?: string }) {
  const now=nowMs(), start=x.l.startAt.getTime(), end=start+x.l.duration*60_000;
  // A student must see their own local time; only a tutor sees the teacher zone.
  const preferredZone = isTutor ? x.teacherTimeZone || viewerTimeZone : viewerTimeZone;
  const displayZone = isValidTimeZone(preferredZone) ? preferredZone : DEFAULT_TIME_ZONE[lang];
  const shortZone = displayZone.split("/").pop()?.replace(/_/g, " ") || displayZone;
  const active=["pending","confirmed"].includes(x.l.status);
  const roomLabel=x.l.platform==="meet"?c.roomMeet:x.l.platform==="zoom"?c.roomZoom:x.l.platform==="lingo"?c.roomLingo:c.pendingPlatform;
  const late=!isTutor&&x.l.status==="confirmed"&&start-now<12*3600_000;
  const startsSoon=x.l.status==="confirmed"&&start-now<=10*60_000&&start-now>0;
  const studentCanJoin = !isTutor && x.l.status === "confirmed" &&
    start - now <= 10 * 60_000 && now < end + 15 * 60_000 &&
    ["lingo", "meet", "zoom", "daily"].includes(x.l.platform);
  const classroomHref = `/classroom/${x.l.id}${studentCanJoin ? "?join=1" : ""}`;
  return <article className="rounded-2xl border border-slate-100 bg-white p-4 sm:p-5">
    <div className="flex flex-wrap items-start gap-3"><img src={x.otherAvatar||""} alt="" width={44} height={44} loading="lazy" className="h-11 w-11 rounded-xl bg-slate-100 object-cover"/><div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-teal-950">{x.otherName}</h3><p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500"><Icon name="calendar" width={13} height={13}/>{fmtAtZone(x.l.startAt,lang,displayZone)} <span className="text-slate-400">· {shortZone}</span><span className="px-0.5 text-slate-300">/</span>{x.l.duration} {c.minutes}<span className="px-0.5 text-slate-300">/</span>{money(x.l.price)}</p></div><span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${statusColor[x.l.status]}`}>{t[`status_${x.l.status}` as keyof T]}</span></div>
    {(x.l.topic||x.l.teacherNotes)&&<div className="mt-3 pl-0 text-xs leading-6 text-slate-500 sm:pl-[56px]">{x.l.topic&&<p>{x.l.topic}</p>}{x.l.teacherNotes&&<p className="mt-1 rounded-lg bg-amber-50/70 px-3 py-2"><b>{t.notes}: </b>{x.l.teacherNotes}</p>}</div>}
    <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-50 pt-3"><div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400">{x.l.packageId&&<span className="flex items-center gap-1.5 rounded-md bg-teal-50 px-2 py-1 text-teal-700"><Icon name="box" width={12} height={12}/>{c.packageCredit} #{x.l.packageId}</span>}{x.l.trial&&<span className="rounded-md bg-amber-50 px-2 py-1 text-amber-700">{t.trial}</span>}{active&&<span className="flex items-center gap-1.5"><Icon name="video" width={13} height={13}/>{roomLabel}</span>}</div><div className="flex flex-wrap items-center gap-2">{active&&<Link href={classroomHref} prefetch={false} className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold text-white hover:bg-teal-900 ${startsSoon?"animate-pulse bg-amber-600 ring-2 ring-amber-300 ring-offset-2":"bg-teal-800"}`}><Icon name={isTutor?"settings":"video"} width={14} height={14}/>{studentCanJoin ? "Enter classroom" : startsSoon ? "Starts soon · Enter class" : isTutor ? (x.l.platform === "undecided" ? c.choosePlatform : c.manageRoom) : "View classroom"}</Link>}{isTutor&&x.l.status==="pending"&&<form action={updateLesson as unknown as (fd: FormData) => Promise<void>}><input type="hidden" name="id" value={x.l.id}/><button name="action" value="confirm" className="rounded-lg bg-sky-50 px-3 py-2 text-xs font-semibold text-sky-700">{t.confirm}</button></form>}{isTutor&&x.l.status==="confirmed"&&now>=end&&<form action={updateLesson as unknown as (fd: FormData) => Promise<void>} className="flex gap-1"><input type="hidden" name="id" value={x.l.id}/><input name="notes" maxLength={1000} placeholder={t.notes} className="w-28 rounded-lg border border-slate-200 px-2 text-xs"/><button name="action" value="complete" className="rounded-lg bg-teal-50 px-3 py-2 text-xs font-semibold text-teal-700">{t.complete}</button></form>}{active&&<form action={updateLesson as unknown as (fd: FormData) => Promise<void>}><input type="hidden" name="id" value={x.l.id}/><CancelLessonButton label={t.cancel} message={t.cancelLate} late={late}/></form>}</div></div>
    {!isTutor&&x.l.status==="completed"&&!(x.reviewedByMe ?? x.l.reviewed)&&<form action={leaveReview as unknown as (fd: FormData) => Promise<void>} className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4"><input type="hidden" name="id" value={x.l.id}/><select name="rating" aria-label="Rating" className="rounded-lg border border-slate-200 px-2 py-2 text-xs">{[5,4,3,2,1].map(n=><option key={n} value={n}>{n} / 5</option>)}</select><input name="comment" maxLength={1000} placeholder={t.leaveReview} className="min-w-0 flex-1 rounded-lg border border-slate-200 px-3 text-xs"/><button className="rounded-lg bg-amber-200 px-3 py-2 text-xs font-bold text-teal-950">{t.submit}</button></form>}
  </article>;
}
export default function DashboardLessons({ rows, isTutor, t, c, lang, booked, viewerTimeZone }: { rows: LessonRowData[]; isTutor: boolean; t: T; c: LearningCopy; lang: Lang; booked?: boolean; viewerTimeZone?: string }) {
  const upcoming=rows.filter(x=>["pending","confirmed"].includes(x.l.status));
  const past=rows.filter(x=>!upcoming.includes(x)).reverse();
  return <div className="space-y-6">{booked&&<p className="rounded-2xl bg-teal-50 p-4 text-sm font-medium text-teal-800">{t.booked} {!isTutor&&c.teacherDecides}</p>}{[[t.upcoming,upcoming],[t.past,past]].map(([title,list])=><section key={title as string} className="rounded-[24px] border border-slate-200 bg-white p-5 sm:p-6"><h2 className="mb-5 text-lg font-bold text-teal-950">{title as string}</h2><div className="space-y-3">{(list as LessonRowData[]).map(row=><DashboardLessonRow key={row.l.id} row={row} isTutor={isTutor} t={t} c={c} lang={lang} viewerTimeZone={viewerTimeZone}/>)}</div>{!(list as LessonRowData[]).length&&<p className="py-4 text-sm text-slate-400">{t.noLessons}</p>}</section>)}</div>;
}
